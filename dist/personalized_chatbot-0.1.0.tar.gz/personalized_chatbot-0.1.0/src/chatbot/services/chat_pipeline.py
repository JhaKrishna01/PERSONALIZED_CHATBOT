"""Core orchestration pipeline for the chatbot."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ..emotion import EmotionDetector
from ..llm import TherapeuticResponder
from ..safety import SafetyAdvisor
from ..vector_stub import VectorRetrievalStub
from ..voice import VoiceProcessor


@dataclass
class PipelineResult:
    """Structured output of the chat pipeline."""

    reply: str
    detected_emotions: List[str]
    risk_level: str
    safety_actions: List[str]
    retrieved_context: List[str]
    metadata: Dict[str, Any]


class ChatPipeline:
    """Glue code that brings together emotion detection, retrieval, LLM, and safety layers."""

    def __init__(
        self,
        emotion_detector: Optional[EmotionDetector] = None,
        vector_retrieval: Optional[VectorRetrievalStub] = None,
        responder: Optional[TherapeuticResponder] = None,
        safety_advisor: Optional[SafetyAdvisor] = None,
        voice_processor: Optional[VoiceProcessor] = None,
    ) -> None:
        self.emotion_detector = emotion_detector or EmotionDetector()
        self.vector_retrieval = vector_retrieval or VectorRetrievalStub()
        self.responder = responder or TherapeuticResponder()
        self.safety_advisor = safety_advisor or SafetyAdvisor()
        self.voice_processor = voice_processor or VoiceProcessor()

    def run_chat(
        self,
        user_id: str,
        user_message: str,
        modalities: List[str],
        audio_bytes: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Execute the end-to-end chat flow."""
        transcript = user_message
        voice_emotions: List[str] = []

        if "audio" in modalities and audio_bytes:
            transcript, voice_emotions = self.voice_processor.process_audio(audio_bytes)

        emotion_result = self.emotion_detector.detect(
            transcript=transcript,
            voice_emotions=voice_emotions,
        )

        retrieved_snippets = self.vector_retrieval.fetch_personalized_context(
            user_id=user_id,
            query=transcript,
        )

        llm_reply = self.responder.generate_response(
            user_message=transcript,
            emotions=emotion_result.emotions,
            risk_level=emotion_result.risk_level,
            retrieved_context=retrieved_snippets,
        )

        safety_outcome = self.safety_advisor.evaluate(
            message=transcript,
            llm_reply=llm_reply,
            risk_level=emotion_result.risk_level,
        )

        result = PipelineResult(
            reply=llm_reply,
            detected_emotions=emotion_result.emotions,
            risk_level=emotion_result.risk_level,
            safety_actions=safety_outcome.actions,
            retrieved_context=retrieved_snippets,
            metadata={
                "user_id": user_id,
                "modality": modalities,
            },
        )

        return {
            "reply": result.reply,
            "emotions": result.detected_emotions,
            "risk_level": result.risk_level,
            "safety_actions": result.safety_actions,
            "retrieved_context": result.retrieved_context,
            "metadata": result.metadata,
        }