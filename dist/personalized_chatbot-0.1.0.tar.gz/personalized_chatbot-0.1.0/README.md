# Personalized, Emotion-Aware Conversational Assistant

Prototype implementation of a mental-health-oriented chatbot that blends emotion detection, retrieval-augmented responses, safety guardrails, and optional voice processing.

## Features
- Flask-based API with `/api/v1/chat` endpoint.
- Emotion detection stub that combines text and (future) voice cues.
- Vector database integration point exposed as a stub module for collaborator hand-off.
- Therapeutic response generator following the NURSE framework mindset.
- Safety layer adding disclaimers and high-risk escalation hooks.
- Voice pipeline placeholder ready for speech-to-text integration.

## Project Layout
```
PERSONALIZED_CHATBOT/
├── README.md
├── pyproject.toml
├── docs/
│   └── design/
│       └── architecture.md
├── src/
│   └── chatbot/
│       ├── __init__.py
│       ├── app.py
│       ├── wsgi.py
│       ├── routes/
│       │   └── v1/
│       │       ├── __init__.py
│       │       └── endpoints.py
│       ├── services/
│       │   └── chat_pipeline.py
│       ├── emotion/
│       │   ├── __init__.py
│       │   └── detector.py
│       ├── llm/
│       │   ├── __init__.py
│       │   └── therapeutic_responder.py
│       ├── safety/
│       │   ├── __init__.py
│       │   └── advisor.py
│       ├── vector_stub/
│       │   ├── __init__.py
│       │   └── stub.py
│       └── voice/
│           ├── __init__.py
│           └── processor.py
└── .zencoder/
    └── rules/
        └── repo.md
```

## Quick Start
1. **Create virtual environment** (already provisioned as `venv/` if desired):
   ```powershell
   python -m venv "c:\Users\KRISHNSA JHA\OneDrive - vitap.ac.in\Desktop\github project\PERSONALIZED_CHATBOT\venv"
   "c:\Users\KRISHNSA JHA\OneDrive - vitap.ac.in\Desktop\github project\PERSONALIZED_CHATBOT\venv\Scripts\activate"
   ```
2. **Install dependencies**:
   ```powershell
   pip install -e .
   ```
3. **Run development server**:
   ```powershell
   flask --app chatbot.wsgi run --debug
   ```
4. **Test endpoints** (PowerShell example):
   ```powershell
   Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:5000/api/v1/chat" -Body (@{user_id="demo"; message="I'm feeling sad today"} | ConvertTo-Json) -ContentType "application/json"
   ```

## Vector Database Placeholder
- `src/chatbot/vector_stub/stub.py` contains `VectorRetrievalStub`, which returns canned context snippets. Your collaborator can replace this with real vector database logic without changing the pipeline API.

## Next Steps
- Integrate production-grade emotion detection and speech pipelines.
- Replace the response stub with calls to a therapeutic-tuned LLM.
- Expand the safety advisor with concrete escalation workflows and hotline data.
- Add tests under `tests/` once implementation details solidify.