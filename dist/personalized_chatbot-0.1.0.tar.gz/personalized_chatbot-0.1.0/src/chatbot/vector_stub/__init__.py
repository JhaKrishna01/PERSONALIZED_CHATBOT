"""Stub module for vector database interactions."""

from .stub import VectorRetrievalStub  # noqa: F401