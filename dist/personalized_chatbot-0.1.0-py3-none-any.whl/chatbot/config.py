"""Configuration utilities for environment-dependent settings."""
from __future__ import annotations

import os
from functools import lru_cache
from typing import Optional

from dotenv import load_dotenv


# Load environment variables from a local .env if present.
load_dotenv()


class MissingEnvironmentVariable(RuntimeError):
    """Raised when a required environment variable is not defined."""


@lru_cache(maxsize=None)
def get_env(key: str, default: Optional[str] = None, *, required: bool = False) -> str:
    """Retrieve an environment variable, optionally enforcing its presence.

    Args:
        key: Name of the environment variable to fetch.
        default: Optional fallback value if the variable is unset.
        required: When ``True``, raises ``MissingEnvironmentVariable`` if the
            variable is not defined and no default is provided.

    Returns:
        The resolved environment variable value (or the provided default).

    Raises:
        MissingEnvironmentVariable: If ``required`` is ``True`` and the
            variable is missing.
    """

    value = os.getenv(key, default)
    if required and value is None:
        raise MissingEnvironmentVariable(
            f"Environment variable '{key}' must be set for this component to function."
        )
    return value