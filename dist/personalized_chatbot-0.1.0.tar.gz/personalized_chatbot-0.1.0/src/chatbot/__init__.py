"""Top-level package for the personalized, emotion-aware chatbot."""

from .app import create_app  # noqa: F401