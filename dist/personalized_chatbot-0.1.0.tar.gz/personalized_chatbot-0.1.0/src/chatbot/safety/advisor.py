"""Safety layer that injects disclaimers and escalation guidance."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class SafetyOutcome:
    """Result produced by the safety advisor."""

    actions: List[str] = field(default_factory=list)
    disclaimer: str | None = None


class SafetyAdvisor:
    """Placeholder safety evaluator.

    Replace with policies that integrate clinical oversight, helpline escalation,
    and content moderation models.
    """

    def evaluate(
        self,
        message: str,
        llm_reply: str,
        risk_level: str,
    ) -> SafetyOutcome:
        outcome = SafetyOutcome(actions=[])

        # Universal disclaimer
        outcome.actions.append(
            "append_disclaimer"
        )
        outcome.disclaimer = (
            "I’m not a medical professional, but I can help you find resources."
        )

        if risk_level == "high":
            outcome.actions.extend([
                "suggest_immediate_help",
                "list_crisis_hotline",
            ])

        return outcome