"""Emotion detector stub that combines text and optional voice cues."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass
class EmotionDetectionResult:
    """Structured result from the emotion detector."""

    emotions: List[str]
    risk_level: str
    confidence: Dict[str, float]


class EmotionDetector:
    """Placeholder emotion detector.

    Replace the dummy implementation with a transformer-based classifier or
    ensemble that combines text sentiment, emotion classes, and crisis signals.
    """

    def detect(
        self,
        transcript: str,
        voice_emotions: Optional[List[str]] = None,
    ) -> EmotionDetectionResult:
        # TODO: Replace heuristic with actual model predictions.
        normalized_text = transcript.lower()

        heuristics: List[str] = []
        confidence: Dict[str, float] = {}

        if any(word in normalized_text for word in ("sad", "down", "depressed")):
            heuristics.append("sadness")
            confidence["sadness"] = 0.7
        if any(word in normalized_text for word in ("angry", "frustrated", "mad")):
            heuristics.append("anger")
            confidence["anger"] = 0.6
        if "self-harm" in normalized_text or "suicide" in normalized_text:
            heuristics.append("crisis")
            confidence["crisis"] = 0.9

        # Merge voice-derived emotions if provided
        if voice_emotions:
            for emotion in voice_emotions:
                heuristics.append(emotion)
                confidence[emotion] = max(confidence.get(emotion, 0.0), 0.5)

        if not heuristics:
            heuristics.append("neutral")
            confidence["neutral"] = 0.5

        risk_level = "high" if "crisis" in heuristics else "moderate" if len(heuristics) > 1 else "low"

        return EmotionDetectionResult(
            emotions=heuristics,
            risk_level=risk_level,
            confidence=confidence,
        )