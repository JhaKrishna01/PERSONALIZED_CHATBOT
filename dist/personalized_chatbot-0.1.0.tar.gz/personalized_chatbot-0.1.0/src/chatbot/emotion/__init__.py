"""Emotion and risk detection package."""

from .detector import EmotionDetector, EmotionDetectionResult  # noqa: F401